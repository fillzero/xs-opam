ocaml-qmp
=========

OCaml implementation of the Qemu Monitor Protocol (QMP)

QuickStart
----------

Install the dependencies using OPAM:

    opam install yojson cmdliner ocamlfind

Build the library, tests and CLI:

    make

Try the CLI:

    ./dist/build/cli/cli


