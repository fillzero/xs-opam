rsync -av /home/test/soft/xenserver/github/ocaml-qmp/ test@10.71.78.255:/mnt/ocaml-qmp
